package com.nttdata.microstransacciones.business;


import com.nttdata.microstransacciones.model.CuentaRequest;
import com.nttdata.microstransacciones.model.CuentaResponse;
import com.nttdata.microstransacciones.repository.ClientRepository;
import com.nttdata.microstransacciones.repository.CuentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CuentServiceImp implements CuentService{

    @Autowired
    CuentRepository cuentRepository;

    @Autowired
    CuentMapper cuentMapper;

    @Override
    public List<CuentaResponse> listCuentas() {
        return cuentRepository.findAll().stream()
                .map(m->cuentMapper.getCuentaResponse(m))
                .collect(Collectors.toList());
    }

    @Override
    public CuentaResponse registerRetiro(CuentaRequest cuentaRequest) {
        return cuentMapper
                .getCuentaResponse(cuentRepository.save(cuentMapper.getCuentaEntity(cuentaRequest)));
    }

    @Override
    public CuentaResponse registerDeposito(CuentaRequest cuentaRequest) {
        return cuentMapper
                .getCuentaResponse(cuentRepository.save(cuentMapper.getCuentaEntity(cuentaRequest)));
    }

    @Override
    public CuentaResponse registerTransferencia(CuentaRequest cuentaRequest) {
        return cuentMapper
                .getCuentaResponse(cuentRepository.save(cuentMapper.getCuentaEntity(cuentaRequest)));
    }

}
