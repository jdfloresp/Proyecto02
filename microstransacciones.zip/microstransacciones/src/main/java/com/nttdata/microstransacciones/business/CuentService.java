package com.nttdata.microstransacciones.business;

import com.nttdata.microstransacciones.model.ClienteRequest;
import com.nttdata.microstransacciones.model.ClienteResponse;
import com.nttdata.microstransacciones.model.CuentaRequest;
import com.nttdata.microstransacciones.model.CuentaResponse;

import java.util.List;

public interface CuentService {

    //public CuentaResponse registerCuenta(CuentaRequest cuentaRequest) ;

    List<CuentaResponse> listCuentas();

    CuentaResponse registerRetiro(CuentaRequest cuentaRequest);

    CuentaResponse registerDeposito(CuentaRequest cuentaRequest);

    CuentaResponse registerTransferencia(CuentaRequest cuentaRequest);
}
