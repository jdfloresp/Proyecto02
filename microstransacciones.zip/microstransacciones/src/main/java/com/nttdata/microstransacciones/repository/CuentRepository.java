package com.nttdata.microstransacciones.repository;

import com.nttdata.microstransacciones.model.entity.Cuent;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface CuentRepository extends MongoRepository<Cuent ,String> {
}
