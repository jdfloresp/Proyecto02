package com.nttdata.microstransacciones.model.entity;


import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;
import java.time.LocalTime;

@Data
@Document (collection = "cuenta")

public class Cuent {

    @Id
    private String Cuentaid;
    private String datosCliente;
    private String numCuenta;
    private Integer saldo;
    private String tipoCuenta;
    private String tipoMovimiento;
    private String cuentaDestino;
    private LocalDate fechaMovimiento;

}
