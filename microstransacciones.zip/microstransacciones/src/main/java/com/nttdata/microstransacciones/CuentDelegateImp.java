package com.nttdata.microstransacciones;


import com.nttdata.microstransacciones.api.CuentaApiDelegate;
import com.nttdata.microstransacciones.business.CuentService;
import com.nttdata.microstransacciones.model.CuentaRequest;
import com.nttdata.microstransacciones.model.CuentaResponse;
import lombok.SneakyThrows;
import org.apache.coyote.BadRequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CuentDelegateImp implements CuentaApiDelegate {

    @Autowired
    CuentService cuentService;

    @Override
    public ResponseEntity<List<CuentaResponse>> listCuentas() {
        return ResponseEntity.ok(cuentService.listCuentas());
    }


    //filtrar
    @Override
    public ResponseEntity<CuentaResponse> registerDeposito(CuentaRequest cuentaRequest) {
        validarDepositoyRetiro(cuentaRequest);
        cuentaRequest.setTipoMovimiento("DEPOSITO");
        return ResponseEntity.ok(cuentService.registerDeposito(cuentaRequest));
    }

    @Override
    public ResponseEntity<CuentaResponse> registerRetiro(CuentaRequest cuentaRequest) {
        validarDepositoyRetiro(cuentaRequest);
        cuentaRequest.setTipoMovimiento("RETIRO");
        return ResponseEntity.ok(cuentService.registerDeposito(cuentaRequest));
    }

    @Override
    public ResponseEntity<CuentaResponse> registerTransferencia(CuentaRequest cuentaRequest) {
        validarTransaccion(cuentaRequest);
        cuentaRequest.setTipoMovimiento("TRANSFERENCIA");
        return ResponseEntity.ok(cuentService.registerDeposito(cuentaRequest));
    }

    @SneakyThrows
    public void validarDepositoyRetiro (CuentaRequest cuentaRequest){

        if (cuentaRequest.getCuentaDestino() != null && !cuentaRequest.getCuentaDestino().isEmpty()){
            throw new BadRequestException("No hay cuenta destino");
        }

        if (cuentaRequest.getNumCuenta() ==null || cuentaRequest.getNumCuenta().isEmpty()){
            throw new BadRequestException("Se requiere cuenta destino");
        }
    }


    @SneakyThrows
    public void validarTransaccion (CuentaRequest cuentaRequest){

        if (cuentaRequest.getNumCuenta() != null && !cuentaRequest.getNumCuenta().isEmpty()){
            throw new BadRequestException("No hay cuenta destino");
        }

        if (cuentaRequest.getCuentaDestino() ==null || cuentaRequest.getCuentaDestino().isEmpty()){
            throw new BadRequestException("Se solicita cuenta de destino");
        }
    }


}
