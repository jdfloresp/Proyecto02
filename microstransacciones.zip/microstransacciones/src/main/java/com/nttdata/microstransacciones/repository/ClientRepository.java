package com.nttdata.microstransacciones.repository;

import com.nttdata.microstransacciones.model.entity.Client;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ClientRepository extends MongoRepository<Client,Integer> {
}
