package com.nttdata.microstransacciones.business;

import com.nttdata.microstransacciones.model.ClienteRequest;
import com.nttdata.microstransacciones.model.ClienteResponse;
import com.nttdata.microstransacciones.model.CuentaRequest;
import com.nttdata.microstransacciones.model.CuentaResponse;
import com.nttdata.microstransacciones.model.entity.Client;
import com.nttdata.microstransacciones.model.entity.Cuent;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;


@Component
public class CuentMapper {


    //registrar cuenta//
    public Cuent getCuentaEntity(CuentaRequest request){
        Cuent entity = new Cuent();
        entity.setCuentaid(request.getCuentaid());
        entity.setDatosCliente(request.getDatosCliente());
        entity.setNumCuenta(request.getNumCuenta());
        entity.setSaldo(request.getSaldo());
        entity.setTipoCuenta(request.getTipoCuenta());
        entity.setTipoMovimiento(request.getTipoMovimiento());
        entity.setCuentaDestino(request.getCuentaDestino());
        entity.setFechaMovimiento(LocalDate.now(ZoneId.of("America/Lima")));
        return entity;

    }

    //listar cuenta//
    public CuentaResponse getCuentaResponse(Cuent entity){
        CuentaResponse response = new CuentaResponse();
        response.setCuentaid(entity.getCuentaid());
        response.setDatosCliente(entity.getDatosCliente());
        response.setNumCuenta(entity.getNumCuenta());
        response.setSaldo(entity.getSaldo());
        response.setTipoCuenta(entity.getTipoCuenta());
        response.setTipoMovimiento(entity.getTipoMovimiento());
        response.setCuentaDestino(entity.getCuentaDestino());
        response.setFechaMovimiento(entity.getFechaMovimiento());
        return response;

    }
}
